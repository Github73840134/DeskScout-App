# Referenced and used variable - but in practice can't be changed.
# Scintilla _only_ supports "utf-8" ATM
default_scintilla_encoding = "utf-8"
